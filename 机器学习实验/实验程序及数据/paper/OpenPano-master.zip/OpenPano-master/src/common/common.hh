#ifdef MSVC
#define not !
#endif
