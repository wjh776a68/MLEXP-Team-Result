#!/bin/bash -e
export LD_PRELOAD=/usr/lib64/libtcmalloc.so
