# PythonCode
Do something with python.
* CaptchaTest  
用Python+Flask制作的一个简易的验证码系统，实现了生成、显示和验证验证码的功能。
* ImageBox
用PyQt5实现一个图片查看器，实现了打开图片、拖动图片、放大和缩小图片等功能。
* LRU  
自定义双向链表，并使用双向链表和哈希表模拟实现LRU Cache。
* PaginateTest  
使用Flask开发的分页Demo，分别使用扩展库flask-pagination和前端框架layui实现分页功能。
* python_ls  
用Python实现Linux中的ls命令，主要使用了argparse和os模块。
* typing  
基于PyQT5开发的打字训练小工具，并使用了爬虫爬取文本数据。
